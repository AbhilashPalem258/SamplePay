//
//  SamplePay.h
//  SamplePay
//
//  Created by sapphre on 10/09/19.
//  Copyright © 2019 abhilash. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SamplePay.
FOUNDATION_EXPORT double SamplePayVersionNumber;

//! Project version string for SamplePay.
FOUNDATION_EXPORT const unsigned char SamplePayVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SamplePay/PublicHeader.h>


